local awful = require("awful")
local wibox = require("wibox")
local vicious = require("vicious")
local gears = require("gears")
local beautiful = require("beautiful")

VolumeWidget_prototype = function()
  local this = {}

  this.__public_static = {
    -- Public Static Variables
    -- Public Static Funcs
  }

  this.__private_static = {
    -- Private Static Variables
    config_path = awful.util.getdir("config")
    -- Private Static Funcs
  }

  this.__public = {
    -- Public Variables
    icon = wibox.widget.imagebox(),
    value = wibox.container.background(),
    -- Public Funcs
  }

  this.__private = {
    -- Private Variables
    volume_value = 0,
    is_muted = true,
    textbox = wibox.widget.textbox(),
    -- Private Funcs
    compute_volume_level = function(is_muted, volume_value)
      if (is_muted or volume_value == 0) then
        return "muted"
      elseif volume_value < 30 then
        return "low"
      elseif volume_value < 65 then
        return "medium"
      elseif volume_value <= 100 then
        return "high"
      end
      return "muted"
    end,
    get_number_digits_count = function(number)
      return number < 10 and 1 or (number < 100 and 2 or 3)
    end,
    get_volume_value_string = function()
      return this.__private.volume_value .. "%"
    end
  }

  this.__construct = function(mute_command)
    -- Constructor
    this.__private.textbox.font = "Droid Sans Mono Bold 9"
    this.__public.value.widget = this.__private.textbox

    vicious.register(this.__public.icon, vicious.widgets.volume,
      function (widget, args)
        this.__private.volume_value = args[1]
        this.__private.is_muted = args[2] == "🔈"
        this.__public.icon.image = gears.color.recolor_image(this.__private_static.config_path .. "/themes/relz/icons/widgets/volume/volume_" .. this.__private.compute_volume_level(this.__private.is_muted, this.__private.volume_value) .. ".svg", beautiful.text_color)
        this.__private.textbox.text = string.rep(" ", 3 - this.__private.get_number_digits_count(this.__private.volume_value)) .. this.__private.get_volume_value_string() .. " "
      end,
      2^22,
      "Master"
    )

    this.__public.icon:buttons(awful.util.table.join(awful.button({}, 1,
        function ()
            awful.spawn(mute_command)
            vicious.force({ this.__public.icon })
        end)))

    this.__public.value:buttons(awful.util.table.join(awful.button({}, 1,
        function ()
            awful.spawn(mute_command)
            vicious.force({ this.__public.icon })
        end)))
  end

  return this
end

VolumeWidget = createClass(VolumeWidget_prototype)
